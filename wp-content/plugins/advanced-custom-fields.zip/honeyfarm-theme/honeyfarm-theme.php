<?php
/*
Plugin Name:  Honeyfarm Plugin
Plugin URI:   https://www.honeyfarm.com
Description:  My first plugin for honeyfarm.
Version:      1.0.0
Author:       Siyana Petkova
Author URI:   https://www.honeyfarm.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  honeyfarm
Domain Path:  /languages
*/

include 'includes/cpt-honeyposts.php';

include 'includes/functions.php';