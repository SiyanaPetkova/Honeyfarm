<?php
/*
Plugin Name: HF Custom Gallery
Description: A simple plugin to display all images from the entire website using a shortcode.
Version: 1.0
Author: Siyana Petkova
*/


include 'functions.php';
