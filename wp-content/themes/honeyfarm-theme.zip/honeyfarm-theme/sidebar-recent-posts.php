<div>
    <?php dynamic_sidebar( 'recent-posts' ); ?>
</div>